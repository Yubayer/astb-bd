

<?php $__env->startSection('title', 'AdminBoard'); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-main-content'); ?>
<form class="" action="<?php echo e(route('admin.product.create-new')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
    <div class="card w-100 p-3">
        <div class="card-header text-muted">
            <h3>Create New Product</h3>
        </div>
        <div class="card-body">

        <div class="card mb-3">
            <div class="card-body">
                <div class="mb-3">
                    <label for="colUser" class="form-label">Credentials</label>
                    <input type="text" readonly name="user_role" class="form-control" id="colUser" value="<?php echo e(Auth::user()->role->name); ?>">
                    <input type="hidden" readonly name="user_id" class="form-control" id="colUser" value="<?php echo e(Auth::user()->id); ?>">
                </div>

                <div class="form-row">
                    <div class="col">
                    <input readonly type="text" value="<?php echo e(Auth::user()->name); ?>" class="form-control">
                    </div>
                    <div class="col">
                    <input readonly type="text" value="<?php echo e(Auth::user()->email); ?>" class="form-control">
                    </div>
                </div>
            </div>
        </div>

        <?php if($errors->any()): ?>
            <div class="card my-3 border-danger">
                <div class="card-header text-danger">
                    <h4>Error Occoured, Please Resolve This Errors</h2>
                </div>
                <div class="card-body">
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
            <div class="card">
                <div class="card-body">
                    <div class="mb-3">
                        <label for="collectionName" class="form-label">Enter Product Title</label>
                        <input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" id="collectionName" placeholder="Product Title">
                    </div>

                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="mb-3">
                        <label for="exampleFormControlTextarea1" class="form-label">Product Description</label>
                        <textarea class="form-control" name="description"  id="exampleFormControlTextarea1" placeholder="Product Description..." rows="3"><?php echo e(old('description')); ?></textarea>
                    </div>

                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
            </div> 

            <div class="card my-3">
                <div class="card-body">
                    <div class="form-group">
                        <label for="inputState">Select Collection</label>
                        <select id="inputState" class="form-control" name="collection_id">
                            <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($collection->id); ?>"><?php echo e($collection->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php $__errorArgs = ['collection_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="card my-3">
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col">
                            <label for="price" class="form-label">Enter Product Title</label>
                            <input type="number" name="price" class="form-control" id="price" placeholder="Price">
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col">
                            <label for="comparePrice" class="form-label">Enter Product Title</label>
                            <input type="number" name="compare_price" class="form-control" id="comparePrice" placeholder="Compare Price">
                        </div>
                        <div class="col">
                            <label for="buyPrice" class="form-label">Enter Product Title</label>
                            <input type="number" name="buy_price" class="form-control" id="buyPrice" placeholder="Buy Price">
                        </div>
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <label for="collectionImage" class="form-label">Select Image</label><br>
                <input type="file" name="images[]" class="" id="collectionImage">
            </div>

            <div class="mb-3">
                <label for="collectionImage" class="form-label">Select Image</label><br>
                <input type="file" name="images[]" class="" id="collectionImage">
            </div>

            <div class="mb-3">
                <label for="collectionImage" class="form-label">Select Image</label><br>
                <input type="file" name="images[]" class="" id="collectionImage">
            </div>

            <br>

            <div class="">
                <button type="submit" class="btn btn-dark rounded-0">Create New Product</button>
            </div>
            
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelProjects\Laravel_7\xampp\htdocs\astb-bd\resources\views/admin/product/create.blade.php ENDPATH**/ ?>