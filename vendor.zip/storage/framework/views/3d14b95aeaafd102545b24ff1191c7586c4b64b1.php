

<?php $__env->startSection('title', 'AdminBoard'); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-main-content'); ?>
<form class="" action="<?php echo e(route('admin.product.update')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
    <div class="card w-100 p-3">
        <div class="card-header text-muted">
            <h3>Udpate Product</h3>
        </div>
        <div class="card-body">

        <div class="card mb-3">
            <div class="card-body">
                <div class="mb-3">
                    <label for="colUser" class="form-label">Credentials</label>
                    <input type="text" readonly name="user_role" class="form-control" id="colUser" value="<?php echo e($product->user->role->name); ?>">
                    <input type="hidden" readonly name="user_id" class="form-control" id="colUser" value="<?php echo e(Auth::id()); ?>">
                </div>

                <div class="form-row">
                    <div class="col">
                    <input readonly type="text" value="<?php echo e($product->user->name); ?>" class="form-control">
                    </div>
                    <div class="col">
                    <input readonly type="text" value="<?php echo e($product->user->email); ?>" class="form-control">
                    </div>
                </div>
            </div>
        </div>
        
            <div class="card">
                <div class="card-body">
                    <div class="mb-3">
                        <label for="collectionName" class="form-label">Enter Product Title</label>
                        <input type="text" name="title" class="form-control" id="collectionName" value="<?php echo e($product->title); ?>" placeholder="Product Title">
                    </div>

                    <div class="mb-3">
                        <label for="exampleFormControlTextarea1" class="form-label">Product Description</label>
                        <textarea class="form-control" name="description" id="exampleFormControlTextarea1" placeholder="Product Description..." rows="3"><?php echo e($product->description); ?></textarea>
                    </div>
                </div>
            </div> 

            <div class="card my-3">
                <div class="card-body">
                    <div class="form-group">
                        <label for="inputState">Select Collection</label>
                        <select id="inputState" class="form-control" name="collection_id">
                            <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if($product->collection_id == $collection->id): ?> selected <?php endif; ?> value="<?php echo e($collection->id); ?>"><?php echo e($collection->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="card my-3">
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col">
                            <label for="price" class="form-label">Price</label>
                            <input type="number" name="price" class="form-control" id="price" value="<?php echo e($product->price); ?>" placeholder="Price">
                        </div>
                        <div class="col">
                            <label for="comparePrice" class="form-label">Compare Price</label>
                            <input type="number" name="compare_price" class="form-control" value="<?php echo e($product->compare_price); ?>" id="comparePrice" placeholder="Compare Price">
                        </div>
                        <div class="col">
                            <label for="buyPrice" class="form-label">Buy Price</label>
                            <input type="number" name="buy_price" class="form-control" id="buyPrice" value="<?php echo e($product->buy_price); ?>" placeholder="Buy Price">
                        </div>
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <label for="collectionImage" class="form-label">Select Image</label><br>
                <input type="file" name="images[]" class="" id="collectionImage">
            </div>

            <div class="mb-3">
                <label for="collectionImage" class="form-label">Select Image</label><br>
                <input type="file" name="images[]" class="" id="collectionImage">
            </div>

            <div class="mb-3">
                <label for="collectionImage" class="form-label">Select Image</label><br>
                <input type="file" name="images[]" class="" id="collectionImage">
            </div>

            <br>

            <div class="">
                <button type="submit" class="btn btn-primary">Update product</button>
            </div>
            
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelProjects\Laravel_7\xampp\htdocs\astb-bd\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>