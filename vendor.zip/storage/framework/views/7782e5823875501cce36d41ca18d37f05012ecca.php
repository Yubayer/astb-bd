<aside id="leftsidebar" class="sidebar">
    <!-- User Info -->
    <div class="user-info">
        <div class="image">
            <?php if(Auth::user()->avatar=="profile.jpg"): ?>
            <img src="http://localhost:8000/storage/profile/<?php echo e(Auth::user()->image); ?>" width="48" height="48" alt="User" />
            <?php else: ?>
            <img src="<?php echo e(Auth::user()->avatar); ?>" width="48" height="48" alt="User" />
            <?php endif; ?>
        </div>
        <div class="info-container">
            <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->name); ?></div>
            <div class="email"><?php echo e(Auth::user()->email); ?></div>
            <div class="btn-group user-helper-dropdown">
                <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                <ul class="dropdown-menu pull-right">
                    <li><a href="javascript:void(0);"><i class="material-icons">person</i>Profile</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="javascript:void(0);"><i class="material-icons">group</i>Followers</a></li>
                    <li><a href="javascript:void(0);"><i class="material-icons">shopping_cart</i>Sales</a></li>
                    <li><a href="javascript:void(0);"><i class="material-icons">favorite</i>Likes</a></li>
                    <li role="separator" class="divider"></li>
                    <li>
                      <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                         onclick="event.preventDefault();
                                       document.getElementById('logout-form').submit();">
                          <i class="material-icons">input</i>
                          <?php echo e(__('Logout')); ?>

                      </a>

                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?>
                      </form>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- #User Info -->
    <!-- Menu -->
    <div class="menu">
        <ul class="list">
            <li class="">
                <a href="/admin">
                    <i class="material-icons">video_label</i>
                    <span>Dashboard</span>
                </a>
            </li>
        </ul>
    </div>
    <!-- #Menu -->
    <!-- Footer -->
    <div class="legal">
        <div class="copyright">
            <?php echo e(date("Y")); ?> &copy; Developed by Jobayer Hossain
        </div>
    </div>
    <!-- #Footer -->
</aside>
<?php /**PATH E:\LaravelProjects\Laravel_7\xampp\htdocs\astb-bd\resources\views/layouts/backend/partial/sideber.blade.php ENDPATH**/ ?>