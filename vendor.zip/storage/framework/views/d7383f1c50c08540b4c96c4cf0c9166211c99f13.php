

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/swiper/swiper.css')); ?>"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
    <div class="col-sm-6">
        <div class="card">
        <div class="card-body">
            <?php echo $__env->make('snippets.productSlider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="card rounded-0">
        <div class="card-body">
            
            <div class="card rounded-0 mb-2">
                <div class="card-body">
                    <h4 class="card-title"><?php echo e($product->title); ?></h4>

                    <?php if($product->compare_price == null): ?>
                        <strong class="card-text mb-3">Tk. <?php echo e($product->price); ?></strong>
                    <?php else: ?>
                        <?php if($product->price > $product->compare_price): ?>
                            <strong class="card-text mb-3">
                                <mark>Tk. <?php echo e($product->compare_price); ?></mark> &nbsp;
                                <del style="background: yellow;">Tk. <?php echo e($product->price); ?></del>
                            </strong>
                        <?php else: ?>
                            <strong class="card-text mb-3">Tk. <?php echo e($product->price); ?></strong>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="card rounded-0 mb-2">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('cart.add')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">

                        <div class="form-group w-50">
                            <label for="inputState">Select Quantity</label>
                            <select id="inputState" class="form-control rounded-0" name="quantity">
                                <?php for($i=1; $i<=10; $i++): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>   
                                <?php endfor; ?>
                            </select>
                        </div>

                        <button type="submit" class="w-50 my-3 btn btn-dark rounded-0">Add To Cart</button>
                    </form>
                </div>
            </div>


            <div class="card rounded-0">
                <div class="card-header">
                    <h4>Description</h4>
                </div>
                <div class="card-body">
                <p class="card-text mt-3"><?php echo e($product->description); ?></p>
                </div>
            </div>

        </div>
        </div>
    </div>
    </div>

    <?php if(count($relatedProducts) > 0): ?>
        <?php echo $__env->make('snippets.relatedProduct', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<!-- Swiper JS -->
<script src="<?php echo e(asset('assets/swiper/swiper.js')); ?>"></script>

<!-- Initialize Swiper -->
<script>
  var swiper = new Swiper(".productSwiper", {
    spaceBetween: 30,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelProjects\Laravel_7\xampp\htdocs\astb-bd\resources\views/product.blade.php ENDPATH**/ ?>