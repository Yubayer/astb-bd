

<?php $__env->startSection('title', 'AdminBoard'); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-main-content'); ?>
    <h1>Admin Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelProjects\Laravel_7\xampp\htdocs\astb-bd\resources\views/admin.blade.php ENDPATH**/ ?>