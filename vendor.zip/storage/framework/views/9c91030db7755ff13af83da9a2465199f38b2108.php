
<style>
    .relatedProducts img.card-img-top {
        width: 100%;
        height: 330px;
        object-fit: cover;
        object-position: top;
    }

    .relatedProducts .card-title {
        font-size: 18px;
        padding: 0;
        margin: 0;
    }

    @media(max-width: 480px){
        .relatedProducts img.card-img-top {
            height: 200px;
        }

        .relatedProducts .card-body{
            padding: 10px;
        }

        .relatedProducts .card-title {
            font-size: 15px;
            padding: 0;
            margin: 0;
        }
    }
</style>


<div class="card relatedProducts my-5">
    <div class="card-header">
        <h4>Related Rroducts</h4>
    </div>
    <div class="card-body">
        <div class="row row-cols-2 row-cols-md-4">
            <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col mb-4">
                    <a href="<?php echo e(route('product.index', ['handle' => $product->handle])); ?>">
                        <div class="card h-100">
                            <?php if(count($product->images) > 0): ?>
                                <img src="/images/product/<?php echo e($product->images[0]->url); ?>" 
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img_key=>$image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                data-src_<?php echo e($img_key+1); ?>="/storage/product/<?php echo e($image->url); ?>" 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                class="card-img-top" alt="...">
                            <?php endif; ?>
                            <div class="card-body text-center">
                                <h5 class="card-title"><?php echo e(Str::of($product->title)->words(4, '...')); ?></h5>
                                <p class="card-text">TK. <?php echo e($product->price); ?></p>
                            </div>
                        </div>
                    </a>    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH E:\LaravelProjects\Laravel_7\xampp\htdocs\astb-bd\resources\views/relatedProduct.blade.php ENDPATH**/ ?>