

<?php $__env->startSection('title', 'AdminBoard'); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-main-content'); ?>
    <?php if(Auth::user()->avatar == 'profile.jpg' || Auth::user()->avatar == ''): ?>
    <img class="img-profile"
        src="<?php echo e(asset('assets/img/undraw_profile.svg')); ?>"
        style="width: 300px; heigh: 350px; object-fit: cover; object-position: center;">
    <?php else: ?>
    <img src="/images/profile/<?php echo e(Auth::user()->avatar); ?>" 
        class="img-profile"
        style="width: 300px; heigh: 350px; object-fit: cover; object-position: center;">
    <?php endif; ?>
    <br>
    <?php echo $__env->make('component/modals/updateAdminProfileModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <button class="btn " data-toggle="modal" data-target="#AdminAvatarUpdateModal">Update Avatar</button>
    <hr>
    <h1>Name: <?php echo e(Auth::user()->name); ?></h1>
    <h1>Email: <?php echo e(Auth::user()->email); ?></h1>
    <h1>Role: <?php echo e(Auth::user()->role->name); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelProjects\Laravel_7\xampp\htdocs\astb-bd\resources\views/admin/profile/index.blade.php ENDPATH**/ ?>