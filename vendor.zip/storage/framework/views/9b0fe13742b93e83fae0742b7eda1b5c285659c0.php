

<?php $__env->startPush('css'); ?>
<style>
    .cart-image {
        height: 100%;
        object-fit: cover;
        object-position: top;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<div class="row">
  <div class="col-sm-6">
    <div class="card rounded-0">
        <div class="card-header">
            <h5>Shipping Address</h5>
        </div>
        <div class="card-body">
            <form>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1">
                </div>
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                    <label class="form-check-label" for="exampleCheck1">Check me out</label>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
  </div>

<?php
    $cartTotalPrice = 0;
    foreach($cart as $key => $item){
        if($item->product->compare_price == null){
            $cartTotalPrice = $cartTotalPrice + ($item->product->price * $item->quantity);
        } else{
            if($item->product->price > $item->product->compare_price){
                $cartTotalPrice = $cartTotalPrice + ($item->product->compare_price * $item->quantity);
            }else {
                $cartTotalPrice = $cartTotalPrice + ($item->product->price * $item->quantity);
            }
        }
        
    }
?>

  <div class="col-sm-6">
    <div class="card rounded-0 mb-3">
        <div class="card-body">
        <form>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email address</label>
                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Password</label>
                <input type="password" class="form-control" id="exampleInputPassword1">
            </div>
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        </div>
    </div>
  
    <div class="card rounded-0">
      <div class="card-body">
        <h5 class="card-title">Cart Details</h5>
        <h4>
            <strong>Total Price: <?php echo e($cartTotalPrice); ?></strong>
        </h4>
        <p class="card-text">Cart Items Information</p>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">Product Title</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Unit Price</th>
                    <th scope="col">Total Price</th>
                </tr>
            </thead>
            <tbody>
                 <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($item->product->title); ?></th>
                        <td><?php echo e($item->quantity); ?></td>
                        <td>
                            <?php if($item->product->compare_price == null): ?>
                                    Tk <?php echo e($item->product->price); ?>

                                <?php else: ?>
                                    <?php if($item->product->price > $item->product->compare_price): ?>
                                        Tk <?php echo e($item->product->compare_price); ?>   
                                    <?php else: ?>
                                        Tk <?php echo e($item->product->price); ?>

                                    <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($item->product->compare_price == null): ?>
                                    Tk <?php echo e($item->product->price * $item->quantity); ?>

                                <?php else: ?>
                                    <?php if($item->product->price > $item->product->compare_price): ?>
                                        Tk <?php echo e($item->product->compare_price * $item->quantity); ?>   
                                    <?php else: ?>
                                        Tk <?php echo e($item->product->price * $item->quantity); ?>

                                    <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <a href="<?php echo e(route('cart.checkout')); ?>" class="btn btn-dark rounded-0">Place Order</a>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelProjects\Laravel_7\xampp\htdocs\astb-bd\resources\views/checkout.blade.php ENDPATH**/ ?>