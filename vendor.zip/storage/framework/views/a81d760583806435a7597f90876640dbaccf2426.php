

<?php $__env->startPush('css'); ?>
<style>
    .cart-image {
        height: 100%;
        object-fit: cover;
        object-position: top;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<div class="row">
  <div class="col-sm-6">
        <?php if(count($cart) > 0): ?>
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3 rounded-0">
                    <div class="row no-gutters">
                        <div class="col-md-4">
                        <img class="cart-image" src="/images/product/<?php echo e($item->product->images[0]->url); ?>" alt="<?php echo e($item->product->title); ?>" width="100%">
                        </div>
                        <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title" style="margin:0;"><?php echo e($item->product->title); ?></h5>
                                <?php if($item->product->compare_price == null): ?>
                                    <strong class="card-text mb-3">Tk <?php echo e($item->product->price); ?></strong>
                                <?php else: ?>
                                    <?php if($item->product->price > $item->product->compare_price): ?>
                                        <strong class="card-text mb-3">
                                            <mark>Tk <?php echo e($item->product->compare_price); ?></mark> &nbsp;
                                            <del style="background: yellow;">Tk <?php echo e($item->product->price); ?></del>
                                        </strong>
                                    <?php else: ?>
                                        <strong class="card-text mb-3">Tk <?php echo e($item->product->price); ?></strong>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <form method="POST" action="<?php echo e(route('cart.update')); ?>" class="w-50 mt-2">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($item->id); ?>">

                                <div class="form-group">
                                    <label for="inputState">Update Quantity</label>
                                    <select id="inputState" class="form-control rounded-0" name="quantity">
                                        <?php for($i=1; $i<=10; $i++): ?>
                                            <option <?php if($item->quantity == $i): ?> selected <?php endif; ?> value="<?php echo e($i); ?>"><?php echo e($i); ?></option>   
                                        <?php endfor; ?>
                                    </select>
                                </div>

                                <button type="submit" class="w-100 mt-1 btn btn-info rounded-0">Update</button>
                            </form>
                            
                            <?php echo $__env->make('component.modals.cartDeleteModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <button class="btn btn-warning rounded-0 w-50 mt-1" data-toggle="modal" data-target="#cartDeleteModal">Delete</button>
                        </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <h4>Your Cart is Empty</h4>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-sm btn-info rounded-0">Shopping Now</a>
        <?php endif; ?>
  </div>

<?php
    $cartTotalPrice = 0;
    foreach($cart as $key => $item){
        if($item->product->compare_price == null){
            $cartTotalPrice = $cartTotalPrice + ($item->product->price * $item->quantity);
        } else{
            if($item->product->price > $item->product->compare_price){
                $cartTotalPrice = $cartTotalPrice + ($item->product->compare_price * $item->quantity);
            }else {
                $cartTotalPrice = $cartTotalPrice + ($item->product->price * $item->quantity);
            }
        }
        
    }
?>

  <div class="col-sm-6">
    <div class="card rounded-0">
      <div class="card-body">
        <h5 class="card-title">Cart Details</h5>
        <h4>
            <strong>Total Price: <?php echo e($cartTotalPrice); ?></strong>
        </h4>
        <p class="card-text">Cart Items Information</p>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">Product Title</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Unit Price</th>
                    <th scope="col">Total Price</th>
                </tr>
            </thead>
            <tbody>
                 <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($item->product->title); ?></th>
                        <td><?php echo e($item->quantity); ?></td>
                        <td>
                            <?php if($item->product->compare_price == null): ?>
                                    Tk <?php echo e($item->product->price); ?>

                                <?php else: ?>
                                    <?php if($item->product->price > $item->product->compare_price): ?>
                                        Tk <?php echo e($item->product->compare_price); ?>   
                                    <?php else: ?>
                                        Tk <?php echo e($item->product->price); ?>

                                    <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($item->product->compare_price == null): ?>
                                    Tk <?php echo e($item->product->price * $item->quantity); ?>

                                <?php else: ?>
                                    <?php if($item->product->price > $item->product->compare_price): ?>
                                        Tk <?php echo e($item->product->compare_price * $item->quantity); ?>   
                                    <?php else: ?>
                                        Tk <?php echo e($item->product->price * $item->quantity); ?>

                                    <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <a href="<?php echo e(route('cart.checkout')); ?>" class="btn btn-dark rounded-0">Checkout</a>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelProjects\Laravel_7\xampp\htdocs\astb-bd\resources\views/cart.blade.php ENDPATH**/ ?>