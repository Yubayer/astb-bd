

<?php $__env->startSection('content'); ?>

<style>
    .collection img.card-img-top {
        width: 100%;
        height: 330px;
        object-fit: cover;
        object-position: top;
    }

    .collection .card-title {
        font-size: 18px;
        padding: 0;
        margin: 0;
    }

    .collection a:hover {
        color: inherit;
        text-decoration: none;
    }

    .collection a {
        color: inherit;
        text-decoration: none;
    }

    .collection .card-body{
        position: relative;
    }

    .collection .cart-warpper{
        position: absolute;
        top: -50px;
        left: 0;
        width: 100%;
        background: rgba(0,0,0,.5);
        box-sizing: border-box;
        height: 50px;
        line-height: 52px;
        opacity: 0;
        transition: .3s;
    }

    .collection .cart-icon{

    }

    .product-grid:hover .cart-warpper{
        opacity: 1;
        transition: .3s;
    }

    .collection .fa-solid, .fas {
        font-weight: 900;
        color: #fbff16;
        font-size: 25px;
        box-shadow: 0px 0px 16px 3px #b72727;
    }

    @media(max-width: 480px){
        .collection img.card-img-top {
            height: 200px;
        }

        .collection .card-body{
            padding: 10px;
        }

        .collection .card-title {
            font-size: 15px;
            padding: 0;
            margin: 0;
        }
    }
</style>
    
<div class="card collection rounded-0">
    <div class="card-body">
        <div class="row row-cols-2 row-cols-md-4">
            <?php $__currentLoopData = $collection->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col mb-4">
                    <a href="<?php echo e(route('product.index', ['handle' => $product->handle])); ?>">
                        <div class="card h-100 text-center product-grid">
                            <?php if(count($product->images) > 0): ?>
                                <img src="/images/product/<?php echo e($product->images[0]->url); ?>" 
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img_key=>$image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                data-src_<?php echo e($img_key+1); ?>="/images/product/<?php echo e($image->url); ?>" 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                class="card-img-top" alt="...">
                            <?php endif; ?>
                            <div class="card-body text-center">
                                <h5 class="card-title"><?php echo e(Str::of($product->title)->words(4, '...')); ?></h5>
                                <?php if($product->compare_price == null): ?>
                                    <strong class="card-text mb-3">Tk <?php echo e($product->price); ?></strong>
                                <?php else: ?>
                                    <?php if($product->price > $product->compare_price): ?>
                                        <strong class="card-text mb-3">
                                            <mark>Tk <?php echo e($product->compare_price); ?></mark> &nbsp;
                                            <del style="background: yellow;">Tk <?php echo e($product->price); ?></del>
                                        </strong>
                                    <?php else: ?>
                                        <strong class="card-text mb-3">Tk <?php echo e($product->price); ?></strong>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <div class="cart-warpper">
                                    <div class="cart-icon">
                                    <form method="POST" action="<?php echo e(route('cart.add')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                        <input type="hidden" name="quantity" value="1">
                                        <button type="submit" class="btn"><i class="fa-solid fa-cart-shopping"></i></button>
                                    </form>
                                        
                                    </div>
                                </div>

                            </div>
                            
                        </div>
                    </a>    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelProjects\Laravel_7\xampp\htdocs\astb-bd\resources\views/collection.blade.php ENDPATH**/ ?>