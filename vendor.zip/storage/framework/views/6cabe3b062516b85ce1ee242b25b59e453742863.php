

<?php $__env->startSection('title', 'AdminBoard'); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-main-content'); ?>
<div class="card w-75">
    <div class="card-header text-muted">
        <h3>Create New Collection</h3>
    </div>
    <div class="card-body">
    <form class="" action="<?php echo e(route('admin.collection.create-new')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="colUser" class="form-label">Credentials</label>
            <input type="text" readonly name="user_name" class="form-control" id="colUser" value="<?php echo e(Auth::user()->name); ?>">
            <input type="hidden" readonly name="user_id" class="form-control" id="colUser" value="<?php echo e(Auth::user()->id); ?>">
        </div>

        <div class="mb-3">
            <label for="collectionName" class="form-label">Enter Collection Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" id="collectionName" placeholder="Collection Name">
        </div>

        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">Error: <?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="mb-3">
            <label for="collectionImage" class="form-label">Select Image</label><br>
            <input type="file" name="image" class="" id="collectionImage">
        </div>

        <br>

        <div class="">
            <button type="submit" class="btn btn-primary">Create New</button>
        </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelProjects\Laravel_7\xampp\htdocs\astb-bd\resources\views/admin/collection/create.blade.php ENDPATH**/ ?>