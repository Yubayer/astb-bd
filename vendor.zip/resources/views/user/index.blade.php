@extends('layouts.backend.app')

@section('title', 'User Dashboard')

@push('css')
@endpush

@section('admin-main-content')
    <h1>User Dashboard</h1>
@endsection

@push('js')
  
@endpush
